inp = open("input3.txt", mode='r')
data = inp.readlines()
q = []


def heapify(q, i):
    while i > 0 and q[(i-1)//2][1] > q[i][1]:
        q[i], q[(i-1)//2] = q[(i-1)//2], q[i]
        i = (i-1)//2


def sink(q, i):
    n = len(q)
    l = 2*i+1
    while l < n:
        j = l
        if j+1 < n and q[j+1][1] < q[j][1]:
            j += 1
        if q[i][1] <= q[j][1]:
            break
        q[i], q[j] = q[j], q[i]
        i = j


def enque(name, level, q):
    q.append((name, level))
    heapify(q, len(q)-1)


def seeDoctor(q):
    if not q:
        print("No patients in the queue.")
        return
    name, level = q.pop(0)
    q[0], q[-1] = q[-1], q[0]
    sink(q, 0)
    return name


def printQueue(queue):
    if not queue:
        print("No patients in the queue.")
        return
    print("Current queue:")
    for i in q:
        print(i[0])


def appointment(data, q):
    for i in data:
        name, level = i.split()
        if name == 'see':
            print(seeDoctor(q))
        else:
            enque(name, int(level), q)


appointment(data, q)
inp.close()